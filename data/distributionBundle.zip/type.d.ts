import PropertyTypes from 'clientnode/property-types';
import { Mapping, ObjectMaskConfiguration, PlainObject, Primitive, ProcedureFunction, RecursiveEvaluateable, RecursivePartial, ValueOf } from 'clientnode/type';
import 'grecaptcha';
import { Model as BaseModel } from 'web-input-material/type';
declare global {
    interface Window {
        dataLayer: Array<unknown>;
    }
}
export declare type IndicatorFunction = (..._parameters: Array<unknown>) => boolean;
export declare type DynamicExtendExpression = ((_event: Event, _scope: unknown) => unknown) | string;
export interface Model<T = unknown> extends BaseModel<T> {
    dynamicExtendExpressions?: Mapping<DynamicExtendExpression>;
}
export interface InputConfiguration<Type = unknown> {
    changedEventName?: string;
    dataMapping?: Mapping | string;
    dependsOn?: Array<string> | null;
    domNode?: AnnotatedInputDomNode;
    domNodes: Array<AnnotatedInputDomNode>;
    dynamicExtend?: Mapping<(_event: Event) => unknown>;
    dynamicExtendExpressions?: Mapping<DynamicExtendExpression>;
    name: string;
    properties: Partial<InputAnnotation<Type>>;
    serializer?: (_value: unknown) => Primitive;
    serializerExpression?: string;
    showIf?: IndicatorFunction;
    showIfExpression?: string;
    shown?: boolean;
    target?: string;
    transformer?: (_value: unknown) => unknown;
    transformerExpression?: string;
    value?: null | Type;
    valuePersistence?: 'persistent' | 'resetOnHide';
}
export interface Annotation {
    clearFading?: ProcedureFunction;
    oldDisplay?: string;
    oldOpacity?: number;
    reason: null | Array<string> | string;
    showIf?: IndicatorFunction;
    showIfExpression?: string;
    shown: boolean;
}
export interface InputAnnotation<Type = unknown> {
    changeTrigger?: unknown;
    default: Type;
    dirty: boolean;
    disabled: boolean;
    dynamicExtendExpressions?: Mapping<DynamicExtendExpression>;
    externalProperties?: Partial<InputAnnotation<Type>>;
    initialValue?: Type;
    invalid: boolean;
    model?: RecursivePartial<Model<Type>>;
    pristine: boolean;
    required?: boolean;
    selection: Array<Type>;
    showInitialValidationState: boolean;
    type: string;
    valid: boolean;
    value: Type;
}
export declare type AnnotatedDomNode = HTMLElement & Annotation;
export declare type AnnotatedInputDomNode<Type = unknown> = AnnotatedDomNode & Partial<InputAnnotation<Type>>;
export interface GroupSpecification {
    childs: Array<AnnotatedInputDomNode>;
    showIf?: IndicatorFunction;
    showIfExpression?: string;
    showReason?: Array<AnnotatedDomNode> | null | string;
}
export interface Action {
    code: string;
    indicator: () => unknown;
    name: string;
    target: string;
}
export interface Constraint {
    description: string;
    evaluation: string;
}
export interface StateURL {
    encoded: string;
    plain: string;
}
export interface TargetConfiguration {
    options: RequestInit & Partial<{
        cache: 'default' | 'reload' | 'no-cache';
        credentials: 'omit' | 'same-origin' | 'include';
        headers: Headers | Mapping;
        mode: 'cors' | 'no-cors' | 'same-origin' | 'navigate';
    }>;
    url: string;
}
export declare type Evaluation = [string, () => unknown];
export declare type Expression = [string, string];
export interface Configuration {
    actions: Mapping<Action>;
    animation: boolean;
    constraints: Array<Constraint>;
    data: null | Mapping<unknown>;
    debug: boolean;
    evaluations: Array<Evaluation>;
    expressions: Array<Expression>;
    initializeTarget: TargetConfiguration;
    inputs: Mapping<Partial<InputConfiguration>>;
    name: string;
    offsetInPixel: number;
    reCaptcha: {
        action: ReCaptchaV2.Action;
        key: {
            v2: ReCaptchaV2.Parameters['sitekey'];
            v3: string;
        };
        secret: string;
        skip: boolean;
        token: string;
    };
    responseDataWrapperSelector: {
        optional: boolean;
        path: string;
    };
    securityResponsePrefix: string;
    selector: {
        clearButtons: string;
        groups: string;
        inputs: string;
        reCaptchaFallbackInput: string;
        resetButtons: string;
        spinner: string;
        statusMessageBoxes: string;
        submitButtons: string;
        truncateButtons: string;
    };
    showAll: boolean;
    tag: {
        secret: string;
        values: Array<string> | string;
    };
    tags?: Array<string> | string;
    target: RecursiveEvaluateable<TargetConfiguration>;
    targetData: null | Mapping<unknown>;
    urlConfigurationMask: ObjectMaskConfiguration;
    version: number;
}
export declare type NormalizedConfiguration = Omit<RecursivePartial<Configuration>, 'evaluations' | 'expressions' | 'tag' | 'tags'> & {
    evaluations: Array<Evaluation>;
    expressions: Array<Expression>;
    tag: {
        secret: string;
        values: Array<string>;
    };
};
export interface PropertyTypes {
    baseConfiguration: ValueOf<typeof PropertyTypes>;
    configuration: ValueOf<typeof PropertyTypes>;
    dynamicConfiguration: ValueOf<typeof PropertyTypes>;
}
export declare type FormResponse = Response & {
    data: PlainObject;
};
export declare type ResponseResult = {
    data: Mapping<unknown>;
    invalidInputNames: Array<string>;
};
