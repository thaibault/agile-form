import Tools, { Lock } from 'clientnode';
import { Mapping, Offset, PlainObject, QueryParameters, RecursiveEvaluateable, RecursivePartial } from 'clientnode/type';
import Web from 'web-component-wrapper/Web';
import { WebComponentAPI } from 'web-component-wrapper/type';
import { Action, AnnotatedDomNode, Configuration, Constraint, Evaluation, FormResponse, GroupSpecification, InputConfiguration, NormalizedConfiguration, ResponseResult, StateURL, TargetConfiguration } from './type';
/**
 * Form handler which accepts a various number of content projected dom nodes
 * to interact with them following a given specification object.
 * @property static:baseScopeNames - List of generic scope names available in
 * all evaluations environments.
 * @property static:defaultConfiguration - Holds default extendable
 * configuration object.
 * @property static:specificationToPropertyMapping - Mapping model
 * specification keys to their corresponding input field property name (if not
 * equal).
 * @property static:knownPropertyOrdering - Order of known properties to
 * apply on inputs.
 *
 * @property clearButtons - Reference to form clear button nodes.
 * @property resetButtons - Reference to form reset button nodes.
 * @property spinner - Reference to a spinner dom node.
 * @property statusMessageBoxes - Reference to dom node which holds status
 * messages.
 * @property submitButtons - Reference to submit button nodes.
 * @property truncateButtons - Reference to form truncate buttons.

 * @property dependencyMapping - Mapping from each field to their dependent one.

 * @property groups - Mapping from group dom nodes to containing field names
 * and conditional show if expression.

 * @property determinedTargetURL - Last determined target url.
 * @property initialData - Initialed form input values.
 * @property initialResponse - Initialisation server response.
 * @property latestResponse - Last seen server response.
 * @property message - Current error message about unsatisfied given
 * specification.
 * @property response - Current parsed response from send form data.

 * @property inputEventBindings - Holds a mapping from nodes with registered
 * event handlers mapped to their de-registration function.
 * @property inputConfigurations - Mapping from field name to corresponding
 * configuration.
 * @property inputNames - Specified transformer environment variable names.

 * @property invalid - Indicates whether this form has invalid input.
 * @property invalidConstraint - Indicates whether which constraint or none if
 * none where determined as invalid.
 * @property onceSubmitted - Indicates whether this form was submitted once
 * already.
 * @property pending - Indicates whether a request is currently running.
 * @property submitted - Indicates whether this form state was submitted
 * already.
 * @property valid - Indicates whether this form has valid input.

 * @property reCaptchaFallbackInput - Reference to render re-captcha fallback
 * into.
 * @property reCaptchaFallbackRendered - Indicates whether a fallback
 * re-captcha inputs was already rendered.
 * @property reCaptchaPromise - Reference to re-captcha initialisation promise.
 * @property reCaptchaPromiseResolver - Reference to re-captcha initialisation.
 * @property reCaptchaToken - Last challenge result token promise resolver.

 * @property additionalConfiguration - Holds given configuration object.
 * @property baseConfiguration - Holds given configuration object.
 * @property configuration - Holds given configuration object.
 * @property dynamicConfiguration - Holds given configuration object.
 * @property resolvedConfiguration - Holds given configuration object.
 * @property urlConfiguration - URL given configurations object.
 * @property queryParameters - All determined query parameters.
 *
 * @property lock - Holds lock instance for saving instance specific locks.
 *
 * @property _evaluationResults - Last known evaluation result cache.
 */
export declare class AgileForm<TElement = HTMLElement, ExternalProperties extends Mapping<unknown> = Mapping<unknown>, InternalProperties extends Mapping<unknown> = Mapping<unknown>> extends Web<TElement, ExternalProperties, InternalProperties> {
    static baseScopeNames: Array<string>;
    static content: string;
    static defaultConfiguration: RecursiveEvaluateable<Configuration>;
    static specificationToPropertyMapping: Mapping<{
        invert?: boolean;
        name: string;
    }>;
    static knownPropertyOrdering: Array<string>;
    static _name: string;
    clearButtons: Array<AnnotatedDomNode>;
    resetButtons: Array<AnnotatedDomNode>;
    spinner: Array<AnnotatedDomNode>;
    statusMessageBoxes: Array<AnnotatedDomNode>;
    submitButtons: Array<AnnotatedDomNode>;
    truncateButtons: Array<AnnotatedDomNode>;
    dependencyMapping: Mapping<Array<string>>;
    evaluations: Array<Evaluation>;
    groups: Array<[AnnotatedDomNode, GroupSpecification]>;
    determinedTargetURL: null | string;
    initialData: Mapping<unknown>;
    initialResponse: null | FormResponse;
    latestResponse: null | FormResponse;
    message: string;
    response: null | FormResponse;
    inputEventBindings: Mapping<() => void>;
    inputConfigurations: Mapping<InputConfiguration>;
    inputNames: Array<string>;
    invalid: boolean | null;
    invalidConstraint: Constraint | null;
    onceSubmitted: boolean;
    pending: boolean;
    submitted: boolean;
    valid: boolean | null;
    reCaptchaFallbackInput: AnnotatedDomNode | null;
    reCaptchaFallbackRendered: boolean;
    reCaptchaPromiseResolver: (_result: null | string) => void;
    reCaptchaPromise: Promise<null | string>;
    reCaptchaToken: null | string;
    additionalConfiguration: RecursivePartial<Configuration> | undefined;
    baseConfiguration: RecursivePartial<Configuration> | undefined;
    configuration: RecursivePartial<Configuration> | undefined;
    dynamicConfiguration: RecursivePartial<Configuration> | undefined;
    resolvedConfiguration: Configuration;
    urlConfiguration: null | RecursivePartial<Configuration>;
    queryParameters: QueryParameters;
    readonly self: typeof AgileForm;
    readonly lock: Lock;
    _evaluationResults: Array<unknown>;
    /**
     * Defines dynamic getter and setter interface and resolves configuration
     * object.
     */
    constructor();
    /**
     * Parses given configuration object and delegates to forward them to
     * nested input nodes.
     * @param name - Attribute name which was updates.
     * @param oldValue - Old attribute value.
     * @param newValue - New updated value.
     *
     * @returns Nothing.
     */
    attributeChangedCallback(name: string, oldValue: string, newValue: string): void;
    /**
     * Registers new re-captcha token.
     * @returns Nothing.
     */
    connectedCallback(): void;
    /**
     * De-registers all needed event listener.
     * @returns Nothing.
     */
    disconnectedCallback(): void;
    /**
     * Triggered when content projected and nested dom nodes are ready to be
     * traversed. Selects all needed dom nodes.
     * @param reason - Description why rendering is necessary.
     *
     * @returns A promise resolving to nothing.
     */
    render(reason?: string): Promise<void>;
    /**
     * Fades given dom node to given opacity.
     * @param domNode - Node to fade.
     * @param opacity - Opacity value between 0 and 1.
     * @param durationInMilliseconds - Duration of animation.
     *
     * @returns Nothing.
     */
    fade(domNode: AnnotatedDomNode, opacity?: number, durationInMilliseconds?: number): void;
    /**
     * Adds given dom nodes visual representation.
     * @param domNode - Node to show.
     *
     * @returns Nothing.
     */
    show(domNode: AnnotatedDomNode): void;
    /**
     * Removes given dom nodes visual representation.
     * @param domNode - Node to hide.
     *
     * @returns Nothing.
     */
    hide(domNode: AnnotatedDomNode): void;
    /**
     * Shows the spinner.
     * @returns Nothing.
     */
    showSpinner(): void;
    /**
     * Hides the spinner.
     * @returns Nothing.
     */
    hideSpinner(): void;
    /**
     * Updates given field (by name) visibility state.
     * @param name - Field name to update.
     *
     * @returns A promise resolving to a boolean value indicating whether a
     * visibility change has been happen.
     */
    updateInputVisibility(name: string): Promise<boolean>;
    /**
     * Updates all group visibility states.
     * @returns Nothing.
     */
    updateAllGroups(): void;
    /**
     * Evaluate dynamic text content.
     * @param domNode - Dom node to render its content.
     *
     * @returns Nothing.
     */
    updateGroupContent(domNode: AnnotatedDomNode): void;
    /**
     * Updates current error message box state.
     * @param message - New message string to show.
     *
     * @returns Nothing.
     */
    updateMessageBox(message?: null | string): void;
    /**
     * Normalizes given url configuration to support deprecated formats.
     * 1. Alias top level configuration key "model" to "inputs".
     * 2. Respect top level property configuration (not having nested
     *    "properties" key in input configuration).
     * 3. Alias top level input property configuration "mutable" and "writable"
     *    into properties top level inverted "disabled" configuration.
     * 4. Alias top level input property configuration "nullable" into
     *    properties top level inverted "required" configuration.
     * @param this - Nothing.
     * @param configuration - Configuration object to normalize.
     *
     * @returns Normalized configuration.
     */
    static normalizeURLConfiguration(this: void, configuration: PlainObject): RecursivePartial<Configuration>;
    /**
     * Normalizes given configuration.
     * @param this - Nothing.
     * @param configuration - Configuration object to normalize.
     *
     * @returns Normalized configuration.
     */
    static normalizeConfiguration(this: void, configuration: RecursivePartial<Configuration>): NormalizedConfiguration;
    /**
     * Merge given configuration into resolved configuration object.
     * @param configuration - Configuration to merge.
     *
     * @returns Nothing.
     */
    mergeConfiguration(configuration: RecursivePartial<Configuration>): void;
    /**
     * Resolve and merges configuration sources into final object.
     * @returns Nothing.
     */
    resolveConfiguration(): void;
    /**
     * Determines configuration by existing url parameter.
     * @returns Nothing.
     */
    getConfigurationFromURL(): null | RecursivePartial<Configuration>;
    /**
     * Forwards all input specifications to their corresponding input node.
     * Observes fields for changes to apply specified inter-constraints between
     * them.
     * @returns Nothing.
     */
    configureContentProjectedInputs(): Promise<void>;
    /**
     * Determine all environment variables to ran expressions again. We have to
     * do this a second time to include dynamically added inputs in prototyping
     * mode.
     * @returns Nothing.
     */
    determineInputNames(): void;
    /**
     * Finds all fields and connects them with their corresponding model
     * specification.
     * @returns An object mapping with missing but specified fields.
     */
    connectSpecificationWithDomNodes(): Promise<Mapping<InputConfiguration>>;
    /**
     * Whenever a component is re-configured a digest is needed to ensure that
     * its internal state has been reflected.
     * @returns A promise resolving when digest hast been finished.
    */
    digest(): ReturnType<typeof Tools.timeout>;
    /**
     * Finds all groups and connects them with their corresponding compiled
     * show if indicator functions. Additionally some description will be
     * supplied.
     * @returns Nothing.
     */
    setGroupSpecificConfigurations(): void;
    /**
     * Generates a mapping from each field name to their corresponding
     * dependent field names.
     * @returns Nothing.
     */
    createDependencyMapping(): void;
    /**
     * Pre-compiles specified given expression for given field.
     * @param name - Field name to pre-compile their expression.
     * @param type - Indicates which expression type should be compiled.
     *
     * @returns Nothing.
     */
    preCompileExpressions(name: string, type?: string): void;
    /**
     * Pre-compiles specified given dynamic extend expressions for given field.
     * @param name - Field name to pre-compile their expression.
     *
     * @returns Nothing.
     */
    preCompileDynamicExtendStructure(name: string): void;
    /**
     * Pre-compiles all specified action source expressions.
     * @returns Nothing.
     */
    preCompileActionSources(): void;
    /**
     * Pre-compiles all specified generic expressions.
     * @returns Nothing.
     */
    preCompileGenericExpressions(): void;
    /**
     * Pre-compiles all specified expressions given by the current
     * configuration.
     * @returns Nothing.
     */
    preCompileConfigurationExpressions(): void;
    /**
     * Can be triggered vie provided action condition. Can for example retrieve
     * initial user specific state depending on remote response.
     * @returns Promise resolving to nothing when initial request has been
     * done.
     */
    initialize(): Promise<void>;
    /**
     * Resolve action.
     * @param action - Action to resolve.
     * @param name - Action description.
     *
     * @returns An action url result or undefined.
     */
    resolveAction(action: Action, name: string): null | string;
    /**
     * Sets all given input fields to their corresponding default values.
     * @param event - Triggered event object.
     *
     * @returns Nothing.
     */
    onClear: (event: MouseEvent) => void;
    /**
     * Callback triggered when any keyboard events occur.
     * @param event - Keyboard event object.
     *
     * @returns Nothing.
     */
    onKeyDown: (event: KeyboardEvent) => void;
    /**
     * Sets all given input fields to their corresponding initial values.
     * @param event - Triggered event object.
     *
     * @returns Nothing.
     */
    onReset: (event: MouseEvent) => void;
    /**
     * Triggers form submit.
     * @param event - Triggered event object.
     *
     * @returns Nothing.
     */
    onSubmit: (event: KeyboardEvent | MouseEvent) => void;
    /**
     * Clears all given input fields.
     * @param event - Triggered event object.
     *
     * @returns Nothing.
     */
    onTruncate: (event: MouseEvent) => void;
    /**
     * Sets all given input fields to their initial value.
     * @param event - Triggered event object.
     * @param useDefault - Indicates to use default value while resetting.
     *
     * @returns A promise resolving to nothing.
     */
    doReset: (event: MouseEvent, useDefault?: boolean | null) => Promise<void>;
    /**
     * Sets given input field their initial value.
     * @param name - Name of the field to clear.
     * @param useDefault - Indicates to use default value while resetting.
     *
     * @returns A promise resolving to a boolean indicating whether provided
     * field name exists.
     */
    resetInput(name: string, useDefault?: boolean | null): Promise<boolean>;
    /**
     * Calculates current document relative offset of given dom node's
     * position.
     * @param domNode - Target node to calculate from.
     *
     * @returns Calculated values.
     */
    getOffset(domNode: AnnotatedDomNode): Offset;
    /**
     * Scrolls to given element and focuses it.
     * @param targetDomNode - Dom node to scroll to.
     * @param smooth - Indicates whether to animate scrolling.
     *
     * @returns A promise resolving when focusing has finished.
     */
    scrollAndFocus(targetDomNode: AnnotatedDomNode, smooth?: boolean): Promise<void>;
    /**
     * Sets all hidden non persistent input fields to their initial value.
     * @returns A promise resolving to nothing.
     */
    resetAllHiddenNonPersistentInputs(): Promise<void>;
    /**
     * Retrieves current raw data from given input fields and retrieves invalid
     * fields.
     * @returns An object containing raw data and a list of invalid input
     * fields.
     */
    getData: () => ResponseResult;
    /**
     * Sets global validation message and scrolls to first invalid field.
     * @param data - Data given by the form.
     * @param invalidInputNames - All currently invalid fields names.
     *
     * @returns Nothing.
     */
    handleInvalidSubmittedInput(data: Mapping<unknown>, invalidInputNames: Array<string>): void;
    /**
     * Handle valid sent data and redirects to corresponding specified target
     * page.
     * @param data - Data given by the form.
     * @param newWindow - Indicates whether action targets should be opened in
     * a new window.
     *
     * @returns Redirection target.
     */
    handleValidSentData(data: Mapping<unknown>, newWindow?: boolean): string;
    /**
     * Handles invalid sent data by setting a message and tracking resulting
     * events.
     * @param response - Servers response.
     * @param rawData - Data given by the form.
     *
     * @returns Nothing.
     */
    handleUnsuccessfulSentRequest(response: FormResponse, rawData: null | PlainObject): void;
    /**
     * Sends a request to provided target configuration and triggers different
     * response dependent events.
     * @param target - Configuration how to request.
     * @param rawData - Initial data to sent, needed for tracking additional
     * informations for triggered request.
     *
     * @returns A promise wrapping a boolean indicating the requests result.
     */
    doRequest(target: TargetConfiguration, rawData?: null | PlainObject): Promise<null | FormResponse>;
    /**
     * Send given data to server und interpret response.
     * @param event - Triggering event object.
     * @param data - Valid data given by the form.
     * @param newWindow - Indicates whether action targets should be opened in
     * a new window.
     *
     * @returns Promise holding nothing.
     */
    handleValidSubmittedInput(event: Event, data: Mapping<unknown>, newWindow?: boolean): Promise<void>;
    /**
     * Maps given field names to endpoint's expected ones.
     * @param data - To transform.
     *
     * @returns Resulting transformed data.
     */
    mapTargetNames(data: Mapping<unknown>): Mapping<unknown>;
    /**
     * Check validation state of all content projected inputs, represents
     * overall validation state and sends data to configured target.
     * @param event - Triggered event object.
     *
     * @returns Nothing.
     */
    doSubmit: (event: KeyboardEvent | MouseEvent) => Promise<void>;
    /**
     * Add all needed field event listener to trigger needed checks and start
     * dependent field change cascade.
     * @returns Nothing.
     */
    applyInputBindings(): void;
    /**
     * Updates all fields.
     * @param event - Triggering event object.
     *
     * @returns Promise holding nothing.
     */
    updateAllInputs(event: Event): Promise<void>;
    /**
     * Updates given input (by name) dynamic expression and its visibility
     * state.
     * @param name - Field name to update.
     * @param event - Triggering event object.
     *
     * @returns A Promise resolving to a boolean indicator whether a state
     * changed happened or not.
     */
    updateInput(name: string, event: Event): Promise<boolean>;
    /**
     * Updates all related fields for given field name.
     * @param name - Field to check their dependent fields.
     * @param event - Triggering event.
     *
     * @returns Promise holding nothing.
     */
    updateInputDependencies(name: string, event: Event): Promise<void>;
    /**
     * Trigger inputs internal change detection.
     * @param name - Field name to update their model.
     *
     * @returns A promise resolving to nothing.
     */
    triggerModelUpdate(name: string): Promise<void>;
    /**
     * Derives event name from given event.
     * @param event - Event to derive name from.
     *
     * @returns Derived name.
     */
    determineEventName(event: Event & {
        detail?: {
            parameter?: Array<{
                type?: string;
            }>;
            type?: string;
        };
    }): string;
    /**
     * Evaluate all generic expression results.
     * @returns Nothing.
     */
    runEvaluations(): void;
    /**
     * Indicates a background running process. Sets "pending" property and
     * triggers a loading spinner.
     * @param event - Triggering event object.
     *
     * @returns A Promise resolving when all items render updates has been
     * done.
     */
    startBackgroundProcess(event: Event): Promise<void>;
    /**
     * Stops indicating a background running process. Sets "pending" property
     * and stop showing a loading spinner.
     * @param event - Triggering event object.
     *
     * @returns A Promise resolving when all items render updates has been
     * done.
     */
    stopBackgroundProcess(event: Event): Promise<void>;
    /**
     * Determines whether the current value state can be derived by given
     * configuration or has to be saved.
     * @param name - Model name to derive from.
     *
     * @returns A boolean indicating the neediness.
     */
    determinedStateValueIsNeeded(name: string): boolean;
    /**
     * Determines current state url.
     * @returns URL.
     */
    determineStateURL: () => StateURL;
    /**
     * Tracks given data if tracking environment exists.
     * @param name - Event name to trigger.
     * @param data - Data to track.
     *
     * @returns Nothing.
     */
    triggerEvent(name: string, data: Mapping<unknown>): boolean;
    /**
     * Renders user interaction re-captcha version if corresponding placeholder
     * is available.
     * @returns A boolean indicating if a fallback node was found to render.
     */
    updateReCaptchaFallbackToken(): boolean;
    /**
     * Updates internal saved re-captcha token.
     * @returns Promise resolving to challenge token or null if initialisation
     * was unsuccessful.
     */
    updateReCaptchaToken(): Promise<null | string>;
}
export declare const api: WebComponentAPI<typeof AgileForm>;
export default api;
